package com.diariodehoras.app

import android.Manifest
import android.app.*
import android.content.*
import android.database.sqlite.*
import android.os.*
import android.view.Gravity
import android.widget.*
import androidx.appcompat.app.AppCompatActivity
import java.text.SimpleDateFormat
import java.util.*

data class DiaryEntry(
    val id: Long, val date: String, val start: String, val end: String, val content: String
)

class DiaryDb(context: Context) : SQLiteOpenHelper(context, "diario_de_horas.db", null, 1) {
    override fun onCreate(db: SQLiteDatabase) {
        db.execSQL("CREATE TABLE entries(id INTEGER PRIMARY KEY AUTOINCREMENT, entry_date TEXT NOT NULL, start_time TEXT NOT NULL, end_time TEXT NOT NULL, content TEXT NOT NULL, created_at INTEGER NOT NULL)")
        db.execSQL("CREATE TABLE days(entry_date TEXT PRIMARY KEY, closed INTEGER NOT NULL DEFAULT 0, report TEXT, closed_at INTEGER)")
        db.execSQL("CREATE INDEX entries_date_idx ON entries(entry_date)")
    }
    override fun onUpgrade(db: SQLiteDatabase, oldVersion: Int, newVersion: Int) {}
}

class MainActivity : AppCompatActivity() {
    private lateinit var db: DiaryDb
    private lateinit var entriesContainer: LinearLayout
    private lateinit var historyContainer: LinearLayout
    private lateinit var reportText: TextView
    private lateinit var selectedDateText: TextView
    private lateinit var startInput: EditText
    private lateinit var endInput: EditText
    private lateinit var contentInput: EditText
    private lateinit var addButton: Button
    private lateinit var closeButton: Button

    private val today: String
        get() = SimpleDateFormat("yyyy-MM-dd", Locale.getDefault()).format(Date())

    private var selectedDate = today

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        db = DiaryDb(this)
        buildUi()
        scheduleHourlyReminder()
        requestNotificationPermission()
        refreshScreen()
    }

    private fun buildUi() {
        val root = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setBackgroundColor(getColor(R.color.diary_bg))
            setPadding(20, 20, 20, 12)
        }

        val scroll = ScrollView(this)
        val content = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
        }
        scroll.addView(content)

        content.addView(TextView(this).apply {
            text = "Diário de Horas"
            textSize = 30f
            setTextColor(getColor(R.color.diary_blue))
            setTypeface(null, android.graphics.Typeface.BOLD)
            setPadding(0, 8, 0, 2)
        })

        content.addView(TextView(this).apply {
            text = "Registre o que realmente aconteceu com seu tempo."
            textSize = 15f
            setTextColor(getColor(R.color.diary_muted))
            setPadding(0, 0, 0, 18)
        })

        selectedDateText = TextView(this).apply {
            textSize = 19f
            setTextColor(getColor(R.color.diary_text))
            setTypeface(null, android.graphics.Typeface.BOLD)
            setPadding(0, 8, 0, 10)
        }
        content.addView(selectedDateText)

        val form = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(16, 16, 16, 16)
            setBackgroundColor(getColor(R.color.diary_card))
        }
        content.addView(form)

        val timeRow = LinearLayout(this).apply { orientation = LinearLayout.HORIZONTAL }
        startInput = field("Início", "18:00")
        endInput = field("Fim", "19:00")
        timeRow.addView(startInput, LinearLayout.LayoutParams(0, -2, 1f).apply { rightMargin = 8 })
        timeRow.addView(endInput, LinearLayout.LayoutParams(0, -2, 1f))
        form.addView(timeRow)

        contentInput = EditText(this).apply {
            hint = "O que você fez na última hora?"
            textSize = 16f
            minLines = 3
            gravity = Gravity.TOP
            setPadding(12, 12, 12, 12)
        }
        form.addView(contentInput)

        addButton = Button(this).apply {
            text = "Salvar registro"
            setOnClickListener { addEntry() }
        }
        closeButton = Button(this).apply {
            text = "Fechar dia e gerar relatório"
            setOnClickListener { closeDay() }
        }
        form.addView(addButton)
        form.addView(closeButton)

        content.addView(TextView(this).apply {
            text = "Registros do dia"
            textSize = 18f
            setTypeface(null, android.graphics.Typeface.BOLD)
            setTextColor(getColor(R.color.diary_blue))
            setPadding(0, 18, 0, 8)
        })

        entriesContainer = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
        }
        content.addView(entriesContainer)

        reportText = TextView(this).apply {
            textSize = 15f
            setTextColor(getColor(R.color.diary_text))
            setPadding(4, 18, 4, 18)
        }
        content.addView(reportText)

        content.addView(TextView(this).apply {
            text = "Histórico"
            textSize = 22f
            setTypeface(null, android.graphics.Typeface.BOLD)
            setTextColor(getColor(R.color.diary_blue))
            setPadding(0, 12, 0, 8)
        })

        historyContainer = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
        }
        content.addView(historyContainer)

        root.addView(scroll, LinearLayout.LayoutParams(-1, 0, 1f))
        setContentView(root)
    }

    private fun field(hint: String, value: String) = EditText(this).apply {
        this.hint = hint
        setText(value)
        inputType = android.text.InputType.TYPE_CLASS_DATETIME or
                android.text.InputType.TYPE_DATETIME_VARIATION_TIME
    }

    private fun addEntry() {
        if (isClosed(selectedDate)) {
            toast("Este dia já foi fechado.")
            return
        }

        val text = contentInput.text.toString().trim()
        if (text.isEmpty()) {
            toast("Escreva o que você fez na última hora.")
            return
        }

        db.writableDatabase.insert("entries", null, ContentValues().apply {
            put("entry_date", selectedDate)
            put("start_time", startInput.text.toString().trim())
            put("end_time", endInput.text.toString().trim())
            put("content", text)
            put("created_at", System.currentTimeMillis())
        })

        contentInput.text.clear()
        refreshScreen()
        toast("Registro salvo.")
    }

    private fun closeDay() {
        if (isClosed(selectedDate)) {
            toast("Este dia já está fechado.")
            return
        }

        val entries = getEntries(selectedDate)
        if (entries.isEmpty()) {
            toast("Adicione pelo menos um registro antes de fechar o dia.")
            return
        }

        db.writableDatabase.insertWithOnConflict(
            "days",
            null,
            ContentValues().apply {
                put("entry_date", selectedDate)
                put("closed", 1)
                put("report", buildReport(entries))
                put("closed_at", System.currentTimeMillis())
            },
            SQLiteDatabase.CONFLICT_REPLACE
        )

        refreshScreen()
        toast("Dia fechado e relatório arquivado.")
    }

    private fun refreshScreen() {
        selectedDateText.text =
            if (selectedDate == today) "Hoje • ${displayDate(selectedDate)}"
            else displayDate(selectedDate)

        refreshEntries()
        refreshHistory()

        val closed = isClosed(selectedDate)
        addButton.isEnabled = !closed
        closeButton.isEnabled = !closed
        reportText.text = if (closed) archivedReport(selectedDate) else ""
    }

    private fun refreshEntries() {
        entriesContainer.removeAllViews()
        val entries = getEntries(selectedDate)

        if (entries.isEmpty()) {
            entriesContainer.addView(TextView(this).apply {
                text = "Nenhum registro neste dia."
                textSize = 15f
                setTextColor(getColor(R.color.diary_muted))
                setPadding(4, 4, 4, 12)
            })
            return
        }

        entries.forEach { e ->
            val card = LinearLayout(this).apply {
                orientation = LinearLayout.VERTICAL
                setPadding(14, 12, 14, 12)
                setBackgroundColor(getColor(R.color.diary_card))
                layoutParams = LinearLayout.LayoutParams(-1, -2).apply {
                    bottomMargin = 8
                }
            }

            card.addView(TextView(this).apply {
                text = "${e.start} — ${e.end}"
                textSize = 14f
                setTextColor(getColor(R.color.diary_blue))
                setTypeface(null, android.graphics.Typeface.BOLD)
            })

            card.addView(TextView(this).apply {
                text = e.content
                textSize = 16f
                setTextColor(getColor(R.color.diary_text))
                setPadding(0, 5, 0, 0)
            })

            entriesContainer.addView(card)
        }
    }

    private fun refreshHistory() {
        historyContainer.removeAllViews()

        val dates = mutableSetOf<String>()

        db.readableDatabase.rawQuery(
            "SELECT DISTINCT entry_date FROM entries", null
        ).use { c ->
            while (c.moveToNext()) dates.add(c.getString(0))
        }

        db.readableDatabase.rawQuery(
            "SELECT entry_date FROM days", null
        ).use { c ->
            while (c.moveToNext()) dates.add(c.getString(0))
        }

        if (dates.isEmpty()) {
            historyContainer.addView(TextView(this).apply {
                text = "Seus dias registrados aparecerão aqui."
                setTextColor(getColor(R.color.diary_muted))
            })
            return
        }

        dates.sortedDescending().forEach { date ->
            historyContainer.addView(Button(this).apply {
                text = "${displayDate(date)}${if (isClosed(date)) "  ✓ fechado" else ""}"
                setOnClickListener {
                    selectedDate = date
                    refreshScreen()
                }
            })
        }
    }

    private fun getEntries(date: String): List<DiaryEntry> {
        val list = mutableListOf<DiaryEntry>()

        db.readableDatabase.rawQuery(
            "SELECT id,entry_date,start_time,end_time,content " +
                    "FROM entries WHERE entry_date=? ORDER BY start_time,id",
            arrayOf(date)
        ).use { c ->
            while (c.moveToNext()) {
                list.add(
                    DiaryEntry(
                        c.getLong(0),
                        c.getString(1),
                        c.getString(2),
                        c.getString(3),
                        c.getString(4)
                    )
                )
            }
        }

        return list
    }

    private fun isClosed(date: String): Boolean {
        db.readableDatabase.rawQuery(
            "SELECT closed FROM days WHERE entry_date=?",
            arrayOf(date)
        ).use { c ->
            return c.moveToFirst() && c.getInt(0) == 1
        }
    }

    private fun archivedReport(date: String): String {
        db.readableDatabase.rawQuery(
            "SELECT report FROM days WHERE entry_date=?",
            arrayOf(date)
        ).use { c ->
            if (c.moveToFirst()) {
                return "Relatório arquivado\n\n${c.getString(0) ?: ""}"
            }
        }
        return ""
    }

    private fun buildReport(entries: List<DiaryEntry>) = buildString {
        append("Data: ${displayDate(selectedDate)}\n")
        append("Total de registros: ${entries.size}\n\n")
        entries.forEach {
            append("${it.start} — ${it.end}: ${it.content}\n")
        }
    }.trim()

    private fun displayDate(date: String): String = try {
        val input = SimpleDateFormat("yyyy-MM-dd", Locale.getDefault())
        val output = SimpleDateFormat("dd/MM/yyyy", Locale.getDefault())
        output.format(input.parse(date)!!)
    } catch (_: Exception) {
        date
    }

    private fun scheduleHourlyReminder() {
        val alarm = getSystemService(ALARM_SERVICE) as AlarmManager
        val intent = Intent(this, ReminderReceiver::class.java)
        val pending = PendingIntent.getBroadcast(
            this, 1001, intent,
            PendingIntent.FLAG_UPDATE_CURRENT or PendingIntent.FLAG_IMMUTABLE
        )

        val first = Calendar.getInstance().apply {
            set(Calendar.MINUTE, 0)
            set(Calendar.SECOND, 0)
            set(Calendar.MILLISECOND, 0)
            if (timeInMillis <= System.currentTimeMillis()) {
                add(Calendar.HOUR_OF_DAY, 1)
            }
        }

        alarm.setRepeating(
            AlarmManager.RTC_WAKEUP,
            first.timeInMillis,
            AlarmManager.INTERVAL_HOUR,
            pending
        )
    }

    private fun requestNotificationPermission() {
        if (Build.VERSION.SDK_INT >= 33) {
            requestPermissions(arrayOf(Manifest.permission.POST_NOTIFICATIONS), 20)
        }
    }

    private fun toast(message: String) =
        Toast.makeText(this, message, Toast.LENGTH_SHORT).show()
}
