package com.diariodehoras.app

import android.Manifest
import android.app.*
import android.content.*
import android.content.pm.PackageManager
import android.os.Bundle
import android.text.InputType
import android.view.Gravity
import android.widget.*
import androidx.appcompat.app.AppCompatActivity
import androidx.core.app.ActivityCompat
import java.text.SimpleDateFormat
import java.util.*

data class Entry(val start:String,val end:String,val text:String)

class MainActivity: AppCompatActivity() {
 private val prefs by lazy { getSharedPreferences("diary",MODE_PRIVATE) }
 private val entries=mutableListOf<Entry>()
 private lateinit var list:LinearLayout
 private lateinit var note:EditText
 private lateinit var start:EditText
 private lateinit var end:EditText
 private lateinit var report:TextView

 override fun onCreate(b:Bundle?){super.onCreate(b);load();buildUi();requestNotificationPermission();scheduleHourlyReminder()}
 private fun label(s:String)=TextView(this).apply{text=s;textSize=12f;setPadding(0,20,0,8)}
 private fun timeField()=EditText(this).apply{inputType=InputType.TYPE_CLASS_DATETIME;hint="00:00";setSingleLine()}
 private fun todayKey()=SimpleDateFormat("yyyy-MM-dd",Locale.US).format(Date())

 private fun buildUi(){
  val root=ScrollView(this)
  val w=LinearLayout(this).apply{orientation=LinearLayout.VERTICAL;setPadding(28,32,28,40);setBackgroundColor(0xFFF6F1E8.toInt())}
  root.addView(w)
  w.addView(TextView(this).apply{text="DIÁRIO DE HORAS\n\nSeu dia, registrado hora a hora.";textSize=28f;setTextColor(0xFF17324D.toInt())})
  w.addView(TextView(this).apply{text=SimpleDateFormat("EEEE, dd 'de' MMMM",Locale("pt","BR")).format(Date());textSize=15f;setPadding(0,10,0,22)})
  w.addView(label("HORÁRIO DO REGISTRO"))
  val times=LinearLayout(this).apply{orientation=LinearLayout.HORIZONTAL}
  start=timeField();end=timeField()
  val h=Calendar.getInstance().get(Calendar.HOUR_OF_DAY)
  start.setText(String.format("%02d:00",(h+23)%24));end.setText(String.format("%02d:00",h))
  times.addView(start,LinearLayout.LayoutParams(0,-2,1f));times.addView(Space(this).apply{layoutParams=LinearLayout.LayoutParams(16,1)});times.addView(end,LinearLayout.LayoutParams(0,-2,1f));w.addView(times)
  w.addView(label("O que você fez na última hora?"))
  note=EditText(this).apply{hint="Escreva uma descrição simples do que aconteceu...";minLines=5;gravity=Gravity.TOP;inputType=InputType.TYPE_CLASS_TEXT or InputType.TYPE_TEXT_FLAG_MULTI_LINE};w.addView(note)
  w.addView(Button(this).apply{text="Salvar registro";setOnClickListener{saveEntry()}})
  w.addView(label("REGISTROS DE HOJE"))
  list=LinearLayout(this).apply{orientation=LinearLayout.VERTICAL};w.addView(list);refreshList()
  w.addView(Button(this).apply{text="Fechar dia e gerar relatório";setOnClickListener{closeDay()}})
  report=TextView(this).apply{textSize=15f;setPadding(0,18,0,0)};w.addView(report)
  w.addView(Button(this).apply{text="Ativar alarme de hora em hora";setOnClickListener{scheduleHourlyReminder();Toast.makeText(this@MainActivity,"Alarme ativado",Toast.LENGTH_SHORT).show()}})
  setContentView(root)
 }
 private fun load(){val raw=prefs.getString(todayKey(),"")?:"";if(raw.isNotBlank())raw.split("\n").forEach{val p=it.split("\t",limit=3);if(p.size==3)entries.add(Entry(p[0],p[1],p[2]))}}
 private fun persist(){prefs.edit().putString(todayKey(),entries.joinToString("\n"){"${it.start}\t${it.end}\t${it.text}"}).apply()}
 private fun saveEntry(){val t=note.text.toString().trim();if(t.isEmpty()){note.error="Escreva o que você fez na última hora.";return};entries.add(Entry(start.text.toString(),end.text.toString(),t));entries.sortBy{it.start};persist();note.setText("");refreshList();Toast.makeText(this,"Registro salvo",Toast.LENGTH_SHORT).show()}
 private fun refreshList(){list.removeAllViews();if(entries.isEmpty())list.addView(TextView(this).apply{text="Nenhum registro feito hoje ainda.";setPadding(0,8,0,8)}) else entries.forEach{list.addView(TextView(this).apply{text="${it.start}–${it.end}  ${it.text}";textSize=15f;setPadding(0,10,0,10)})}}
 private fun closeDay(){report.text=buildString{append("RELATÓRIO DO DIA\n\n");if(entries.isEmpty())append("Nenhum registro foi feito neste dia.")else entries.forEach{append("${it.start}–${it.end} — ${it.text}\n")}}}
 private fun requestNotificationPermission(){if(android.os.Build.VERSION.SDK_INT>=33&&ActivityCompat.checkSelfPermission(this,Manifest.permission.POST_NOTIFICATIONS)!=PackageManager.PERMISSION_GRANTED)requestPermissions(arrayOf(Manifest.permission.POST_NOTIFICATIONS),10)}
 private fun scheduleHourlyReminder(){val am=getSystemService(ALARM_SERVICE) as AlarmManager;val pi=PendingIntent.getBroadcast(this,1001,Intent(this,ReminderReceiver::class.java),PendingIntent.FLAG_UPDATE_CURRENT or PendingIntent.FLAG_IMMUTABLE);val c=Calendar.getInstance().apply{set(Calendar.MINUTE,0);set(Calendar.SECOND,0);set(Calendar.MILLISECOND,0);add(Calendar.HOUR,1)};am.setRepeating(AlarmManager.RTC_WAKEUP,c.timeInMillis,3600000L,pi)}
}
