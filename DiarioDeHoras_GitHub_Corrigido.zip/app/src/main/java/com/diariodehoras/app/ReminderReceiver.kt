package com.diariodehoras.app
import android.app.*
import android.content.*
import androidx.core.app.NotificationCompat

class ReminderReceiver: BroadcastReceiver(){
 override fun onReceive(c:Context,i:Intent?){
  val id="hourly_reminder";val m=c.getSystemService(Context.NOTIFICATION_SERVICE) as NotificationManager
  if(android.os.Build.VERSION.SDK_INT>=26)m.createNotificationChannel(NotificationChannel(id,"Diário de Horas",NotificationManager.IMPORTANCE_DEFAULT))
  m.notify((System.currentTimeMillis()/3600000L).toInt(),NotificationCompat.Builder(c,id).setSmallIcon(android.R.drawable.ic_popup_reminder).setContentTitle("Diário de Horas").setContentText("Hora de registrar: o que você fez na última hora?").setAutoCancel(true).build())
 }
}
