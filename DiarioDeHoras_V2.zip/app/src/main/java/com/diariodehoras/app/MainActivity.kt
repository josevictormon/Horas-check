package com.diariodehoras.app

import android.Manifest
import android.app.AlarmManager
import android.app.PendingIntent
import android.content.*
import android.database.sqlite.SQLiteDatabase
import android.database.sqlite.SQLiteOpenHelper
import android.os.Bundle
import android.os.Build
import android.view.Gravity
import android.widget.*
import androidx.appcompat.app.AppCompatActivity
import java.text.SimpleDateFormat
import java.util.*

data class DiaryEntry(
    val id: Long,
    val date: String,
    val start: String,
    val end: String,
    val content: String
)

class DiaryDb(context: Context) : SQLiteOpenHelper(context, "diario_de_horas.db", null, 1) {
    override fun onCreate(db: SQLiteDatabase) {
        db.execSQL("""
            CREATE TABLE entries(
                id INTEGER PRIMARY KEY AUTOINCREMENT,
                entry_date TEXT NOT NULL,
                start_time TEXT NOT NULL,
                end_time TEXT NOT NULL,
                content TEXT NOT NULL,
                created_at INTEGER NOT NULL
            )
        """.trimIndent())
        db.execSQL("""
            CREATE TABLE days(
                entry_date TEXT PRIMARY KEY,
                closed INTEGER NOT NULL DEFAULT 0,
                report TEXT,
                closed_at INTEGER
            )
        """.trimIndent())
        db.execSQL("CREATE INDEX entries_date_idx ON entries(entry_date)")
    }

    override fun onUpgrade(db: SQLiteDatabase, oldVersion: Int, newVersion: Int) {}
}

class MainActivity : AppCompatActivity() {
    private lateinit var db: DiaryDb
    private lateinit var entriesContainer: LinearLayout
    private lateinit var historyContainer: LinearLayout
    private lateinit var reportText: TextView
    private lateinit var selectedDateText: TextView
    private lateinit var startInput: EditText
    private lateinit var endInput: EditText
    private lateinit var contentInput: EditText
    private lateinit var addButton: Button
    private lateinit var closeButton: Button

    private val today: String
        get() = SimpleDateFormat("yyyy-MM-dd", Locale.getDefault()).format(Date())

    private var selectedDate = today

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        db = DiaryDb(this)
        buildUi()
        scheduleHourlyReminder()
        requestNotificationPermission()
        loadDate(today)
    }

    private fun buildUi() {
        val root = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setBackgroundColor(getColor(R.color.diary_bg))
            setPadding(20, 20, 20, 12)
        }

        val scroll = ScrollView(this)
        val content = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
        }
        scroll.addView(content)

        val title = TextView(this).apply {
            text = "Diário de Horas"
            textSize = 30f
            setTextColor(getColor(R.color.diary_blue))
            setTypeface(null, android.graphics.Typeface.BOLD)
            setPadding(0, 8, 0, 2)
        }
        content.addView(title)

        val subtitle = TextView(this).apply {
            text = "Registre o que realmente aconteceu com seu tempo."
            textSize = 15f
            setTextColor(getColor(R.color.diary_muted))
            setPadding(0, 0, 0, 18)
        }
        content.addView(subtitle)

        selectedDateText = TextView(this).apply {
            textSize = 19f
            setTextColor(getColor(R.color.diary_text))
            setTypeface(null, android.graphics.Typeface.BOLD)
            setPadding(0, 8, 0, 10)
        }
        content.addView(selectedDateText)

        val form = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(16, 16, 16, 16)
            setBackgroundColor(getColor(R.color.diary_card))
        }
        content.addView(form)

        val timeRow = LinearLayout(this).apply { orientation = LinearLayout.HORIZONTAL }
        startInput = field("Início", "18:00")
        endInput = field("Fim", "19:00")
        timeRow.addView(startInput, LinearLayout.LayoutParams(0, -2, 1f).apply { rightMargin = 8 })
        timeRow.addView(endInput, LinearLayout.LayoutParams(0, -2, 1f))
        form.addView(timeRow)

        contentInput = EditText(this).apply {
            hint = "O que você fez na última hora?"
            textSize = 16f
            minLines = 3
            gravity = Gravity.TOP
            setPadding(12, 12, 12, 12)
        }
        form.addView(contentInput)

        addButton = Button(this).apply {
            text = "Salvar registro"
            setOnClickListener { addEntry() }
        }
        form.addView(addButton)

        closeButton = Button(this).apply {
            text = "Fechar dia e gerar relatório"
            setOnClickListener { closeDay() }
        }
        form.addView(closeButton)

        reportText = TextView(this).apply {
            textSize = 15f
            setTextColor(getColor(R.color.diary_text))
            setPadding(4, 18, 4, 18)
        }
        content.addView(reportText)

        val historyTitle = TextView(this).apply {
            text = "Histórico"
            textSize = 22f
            setTypeface(null, android.graphics.Typeface.BOLD)
            setTextColor(getColor(R.color.diary_blue))
            setPadding(0, 12, 0, 8)
        }
        content.addView(historyTitle)

        historyContainer = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL }
        content.addView(historyContainer)

        root.addView(scroll, LinearLayout.LayoutParams(-1, 0, 1f))
        setContentView(root)
    }

    private fun field(hint: String, value: String): EditText = EditText(this).apply {
        this.hint = hint
        setText(value)
        inputType = android.text.InputType.TYPE_CLASS_DATETIME or android.text.InputType.TYPE_DATETIME_VARIATION_TIME
    }

    private fun addEntry() {
        if (isClosed(selectedDate)) {
            toast("Este dia já foi fechado.")
            return
        }
        val text = contentInput.text.toString().trim()
        if (text.isEmpty()) {
            toast("Escreva o que você fez na última hora.")
            return
        }

        val values = android.content.ContentValues().apply {
            put("entry_date", selectedDate)
            put("start_time", startInput.text.toString().trim())
            put("end_time", endInput.text.toString().trim())
            put("content", text)
            put("created_at", System.currentTimeMillis())
        }
        db.writableDatabase.insert("entries", null, values)
        contentInput.text.clear()
        loadDate(selectedDate)
        toast("Registro salvo.")
    }

    private fun closeDay() {
        if (isClosed(selectedDate)) {
            toast("Este dia já está fechado.")
            return
        }
        val entries = getEntries(selectedDate)
        if (entries.isEmpty()) {
            toast("Adicione pelo menos um registro antes de fechar o dia.")
            return
        }

        val report = buildReport(entries)
        val values = android.content.ContentValues().apply {
            put("entry_date", selectedDate)
            put("closed", 1)
            put("report", report)
            put("closed_at", System.currentTimeMillis())
        }
        db.writableDatabase.insertWithOnConflict(
            "days", null, values, SQLiteDatabase.CONFLICT_REPLACE
        )
        loadDate(selectedDate)
        toast("Dia fechado e relatório arquivado.")
    }

    private fun loadDate(date: String) {
        selectedDate = date
        selectedDateText.text = if (date == today) "Hoje • ${displayDate(date)}" else displayDate(date)

        val entries = getEntries(date)
        entriesContainer = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL }
        // Rebuild the entry section before history by locating the form's parent content.
        val rootScroll = (findViewById<ScrollView>(android.R.id.content)?.getChildAt(0))
        // Simpler: update the existing layout through a dedicated refresh below.
        refreshDynamicArea(entries)
        refreshHistory()

        val closed = isClosed(date)
        addButton.isEnabled = !closed
        closeButton.isEnabled = !closed
        reportText.text = getReport(date, entries, closed)
    }

    private fun refreshDynamicArea(entries: List<DiaryEntry>) {
        val scroll = window.decorView.findViewById<ScrollView>(android.R.id.content) ?: return
        // The actual content is the first child of the window content.
        val root = scroll.getChildAt(0) as? LinearLayout ?: return
        val content = root.getChildAt(0) as? LinearLayout ?: return

        val markerIndex = content.indexOfChild(reportText)
        // Remove any previous entry cards placed immediately before report.
        while (content.indexOfChild(reportText) > 0 &&
            content.getChildAt(content.indexOfChild(reportText) - 1) is LinearLayout) {
            val candidate = content.getChildAt(content.indexOfChild(reportText) - 1)
            if (candidate !== historyContainer) {
                content.removeView(candidate)
            } else break
        }

        val header = TextView(this).apply {
            text = if (entries.isEmpty()) "Nenhum registro neste dia." else "Registros do dia"
            textSize = 18f
            setTypeface(null, android.graphics.Typeface.BOLD)
            setTextColor(getColor(R.color.diary_blue))
            setPadding(0, 18, 0, 8)
        }
        content.addView(header, content.indexOfChild(reportText))

        entries.forEach { e ->
            val card = LinearLayout(this).apply {
                orientation = LinearLayout.VERTICAL
                setPadding(14, 12, 14, 12)
                setBackgroundColor(getColor(R.color.diary_card))
            }
            val time = TextView(this).apply {
                text = "${e.start} — ${e.end}"
                textSize = 14f
                setTextColor(getColor(R.color.diary_blue))
                setTypeface(null, android.graphics.Typeface.BOLD)
            }
            val body = TextView(this).apply {
                text = e.content
                textSize = 16f
                setTextColor(getColor(R.color.diary_text))
                setPadding(0, 5, 0, 0)
            }
            card.addView(time)
            card.addView(body)
            content.addView(card, content.indexOfChild(reportText))
        }
    }

    private fun refreshHistory() {
        historyContainer.removeAllViews()
        val dates = mutableSetOf<String>()
        db.readableDatabase.rawQuery("SELECT DISTINCT entry_date FROM entries", null).use { c ->
            while (c.moveToNext()) dates.add(c.getString(0))
        }
        db.readableDatabase.rawQuery("SELECT entry_date FROM days", null).use { c ->
            while (c.moveToNext()) dates.add(c.getString(0))
        }

        val ordered = dates.sortedDescending()
        if (ordered.isEmpty()) {
            historyContainer.addView(TextView(this).apply {
                text = "Seus dias registrados aparecerão aqui."
                setTextColor(getColor(R.color.diary_muted))
            })
            return
        }

        ordered.forEach { date ->
            val button = Button(this).apply {
                text = "${displayDate(date)}${if (isClosed(date)) "  ✓ fechado" else ""}"
                setOnClickListener { loadDate(date) }
            }
            historyContainer.addView(button)
        }
    }

    private fun getEntries(date: String): List<DiaryEntry> {
        val list = mutableListOf<DiaryEntry>()
        db.readableDatabase.rawQuery(
            "SELECT id, entry_date, start_time, end_time, content FROM entries WHERE entry_date=? ORDER BY start_time, id",
            arrayOf(date)
        ).use { c ->
            while (c.moveToNext()) {
                list.add(DiaryEntry(c.getLong(0), c.getString(1), c.getString(2), c.getString(3), c.getString(4)))
            }
        }
        return list
    }

    private fun isClosed(date: String): Boolean {
        db.readableDatabase.rawQuery(
            "SELECT closed FROM days WHERE entry_date=?", arrayOf(date)
        ).use { c ->
            return c.moveToFirst() && c.getInt(0) == 1
        }
    }

    private fun getReport(date: String, entries: List<DiaryEntry>, closed: Boolean): String {
        if (!closed) return ""
        db.readableDatabase.rawQuery(
            "SELECT report FROM days WHERE entry_date=?", arrayOf(date)
        ).use { c ->
            if (c.moveToFirst()) return "Relatório arquivado\n\n${c.getString(0) ?: buildReport(entries)}"
        }
        return ""
    }

    private fun buildReport(entries: List<DiaryEntry>): String {
        val sb = StringBuilder()
        sb.append("Data: ").append(displayDate(selectedDate)).append("\n")
        sb.append("Total de registros: ").append(entries.size).append("\n\n")
        entries.forEach {
            sb.append("${it.start} — ${it.end}: ${it.content}\n")
        }
        return sb.toString().trim()
    }

    private fun displayDate(date: String): String {
        return try {
            val input = SimpleDateFormat("yyyy-MM-dd", Locale.getDefault())
            val output = SimpleDateFormat("dd/MM/yyyy", Locale.getDefault())
            output.format(input.parse(date)!!)
        } catch (_: Exception) { date }
    }

    private fun scheduleHourlyReminder() {
        val alarm = getSystemService(ALARM_SERVICE) as AlarmManager
        val intent = Intent(this, ReminderReceiver::class.java)
        val pending = PendingIntent.getBroadcast(
            this, 1001, intent,
            PendingIntent.FLAG_UPDATE_CURRENT or PendingIntent.FLAG_IMMUTABLE
        )
        val first = Calendar.getInstance().apply {
            set(Calendar.MINUTE, 0)
            set(Calendar.SECOND, 0)
            set(Calendar.MILLISECOND, 0)
            if (timeInMillis <= System.currentTimeMillis()) add(Calendar.HOUR_OF_DAY, 1)
        }
        alarm.setRepeating(AlarmManager.RTC_WAKEUP, first.timeInMillis, AlarmManager.INTERVAL_HOUR, pending)
    }

    private fun requestNotificationPermission() {
        if (Build.VERSION.SDK_INT >= 33) {
            requestPermissions(arrayOf(Manifest.permission.POST_NOTIFICATIONS), 20)
        }
    }

    private fun toast(message: String) {
        Toast.makeText(this, message, Toast.LENGTH_SHORT).show()
    }
}
