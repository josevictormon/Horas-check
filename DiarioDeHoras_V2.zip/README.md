# Diário de Horas — versão 2.0

Aplicativo Android independente.

## O que mudou
- Registros persistidos em banco SQLite local.
- Histórico por data.
- Relatórios arquivados quando o usuário fecha o dia.
- O dia não fecha automaticamente à meia-noite.
- Visual inspirado no layout do protótipo do Floot.
- Ícone próprio de relógio + folha para substituir o ícone padrão do Android.
- Lembrete de hora em hora.
- Compatibilidade Java/Kotlin configurada para JVM 17.

O banco fica no próprio celular e não depende do Floot.
